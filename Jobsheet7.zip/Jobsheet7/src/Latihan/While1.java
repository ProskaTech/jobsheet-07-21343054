/*
 * Nama : Maulana Hafizul Haq
 * NIM  : 21343054
 * Prodi: Teknik Informatika
 */
package Latihan;

public class While1 {
    public static void main(String []args) {
        int i = 0;

        while (i <= 10)
        {
            System.out.println(i);
            i++;
        }
    }
}