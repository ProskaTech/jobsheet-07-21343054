/*
 * Nama : Maulana Hafizul Haq
 * NIM  : 21343054
 * Prodi: Teknik Informatika
 */
package Latihan;

public class For3 {
    public static void main(String []args) {
        int bil;
        for(bil = 0 ; bil <= 10 ; bil++)
        System.out.println(bil);
    }
}