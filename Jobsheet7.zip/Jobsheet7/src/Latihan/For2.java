/*
 * Nama : Maulana Hafizul Haq
 * NIM  : 21343054
 * Prodi: Teknik Informatika
 */
package Latihan;

public class For2 {
    public static void main(String []args) {
        int bilangan;
        for(bilangan = 60 ; bilangan >= 10; bilangan -= 10)
        System.out.println(bilangan);
    }
}