/*
 * Nama : Maulana Hafizu Haq
 * NIM  : 21343054
 * Prodi: Teknik Informatika
 */
package Latihan;

public class for1 {
   public static void main (String []args) {
    int bilangan;
    for (bilangan = 20 ; bilangan <= 100 ; bilangan += 10)
    System.out.println(bilangan);
   } 
}
//bilangan = bilangan + 10