/*
 * Nama : Maulana Hafizul Haq
 * NIM  : 21343054
 * Prodi: Teknik Informatika
 */
package Latihan;

public class While2 {
   public static void main(String []args) {
    int i = 20;

    while (i > 10)
    {
        System.out.println("Pemrograman Berorientasi Objek");
        i--;
    }
   } 
}