/*
 * Nama : Maulana Hafizul Haq
 * NIM  : 21343054
 * Prodi: Teknik Informatika
 */
package Tugas;

public class NamaWhile {
    public static void main(String[] args) {
        int i = 0;

        while (i <= 100)
        {
            System.out.println("Maulana Hafizul Haq");
            i++;
        }
    }
}