/*
 * Nama : Maulana Hafizul Haq
 * NIM  : 21343054
 * Prodi: Teknik Informatika
 */
package Tugas;

public class AngkaWhile {
    public static void main(String[] args) {
        int i = 100;

        while (i >= 1)
        {
            System.out.println(i);
            i--;
        }
    }
}