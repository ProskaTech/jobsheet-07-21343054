/*
 * Nama : Maulana Hafizul Haq
 * NIM  : 21343054
 * Prodi: Teknik Informatika
 */
package Tugas;

public class NamaDo_while {
    public static void main(String[] args) {
        int i = 0;

        do
        {
            System.out.println("Maulana Hafizul Haq");
            i++;
        }
        while (i <= 100);
    }
}
