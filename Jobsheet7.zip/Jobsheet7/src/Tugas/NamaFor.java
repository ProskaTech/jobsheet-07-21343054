/*
 * Nama : Maulana Hafizul Haq
 * NIM  : 21343054
 * Prodi: Teknik Informatika
 */
package Tugas;

public class NamaFor {
   public static void main(String[] args) {
    int bilangan;
    for (bilangan = 0 ; bilangan <= 100 ; bilangan += 1)
    System.out.println("Maulana Hafizul Haq");
   } 
}