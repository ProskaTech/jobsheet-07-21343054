/*
 * Nama : Maulana Hafizul Haq
 * NIM  : 21343054
 * Prodi: Teknik Informatika
 */
package Tugas;

public class AngkaFor {
    public static void main(String[] args) {
        int bilangan;
        for (bilangan = 100 ; bilangan > 0 ; bilangan -= 1)
        System.out.println(bilangan); 
    }
}