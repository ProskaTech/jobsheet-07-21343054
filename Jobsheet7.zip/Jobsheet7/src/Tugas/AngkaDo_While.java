/*
 * Nama : Maulana Hafizul Haq
 * NIM  : 21343054
 * Prodi: Teknik Informatika
 */
package Tugas;

public class AngkaDo_While {
    public static void main(String[] args) {
        int i = 100;

        do
        {
            System.out.println(i);
            i--;
        }
        while (i >= 1);
    }
}